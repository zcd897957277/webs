# 0.7 Docs

- [English](https://github.com/vuejs/vue-router/tree/1.0/docs/en)
- [Chinese](https://github.com/vuejs/vue-router/tree/1.0/docs/zh-cn)
- [Japanese](https://github.com/vuejs/vue-router/tree/1.0/docs/ja)
