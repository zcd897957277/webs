import echarts from 'echarts/lib/echarts';

import './flowGL/FlowGLView';
import './flowGL/FlowGLSeries';
