var Carousel={
    img:document.getElementsByClassName("imgs")[0],
    btn:document.getElementsByClassName("btns")[0],
    ZINDEX:0,//�㼶��ϵ
    OPACITY0:1,//͸����
    OPACITY1:0.7,//
    WINTERVAL:0,//ÿ��ͼƬ�ļ��
    TINTERVAL:0,//ÿ��ͼƬ�߶Ȳ�

    ULWIDTH:0,//�ֲ��Ŀ���
    CENTRE:0,
    LIWIDTH:0,//����ͼƬ�Ŀ���
    LITOP:0,//����ͼƬtop
    LILEFT:0,//����ͼƬleft

    DURATION:400,//����ʱ��
    STEP:80,//����
    interval:0,//��Ƶ
    step:0,//ÿ֡����
    top:0,//ÿ֡�߶�
    opacity:0,
    timer:null,//��ʱ��
    moved:0,//������
    canMove:0,
    direction:0,
    init:function(){
        this.CENTRE=this.img.children.length/2-1;
        for(var i=0;i<this.img.children.length;i++){
            this.img.children[i].className+=(" pic"+i);
            this.img.children[i].style.opacity=0.7;
            if(i==this.CENTRE){
                this.img.children[i].style.opacity=1;
            }
        }
        this.LILEFT=parseFloat(getComputedStyle(this.img.children[3]).left);
        this.LIWIDTH=parseFloat(getComputedStyle(this.img.children[3]).width);
        this.WINTERVAL=this.LIWIDTH/8;
        this.TINTERVAL=parseFloat(getComputedStyle(this.img.children[2]).top)-parseFloat(getComputedStyle(this.img.children[3]).top);

        this.interval=this.DURATION/this.STEP;
        this.step=this.WINTERVAL/this.STEP;
        this.top=this.TINTERVAL/this.STEP;
        this.opacity=(this.OPACITY0-this.OPACITY1)/this.STEP;
        this.btn.children[0].addEventListener("click",this.moveLeft.bind(this));
        this.btn.children[1].addEventListener("click",this.moveRight.bind(this));
    },
    moveLeft:function(){
        if(!this.canMove) {
            this.img.children[this.img.children.length-1].className="";
            if(this.direction) {
                for (var i = 0; i < this.img.children.length / 2; i++) {
                    var inner = this.img.children[this.img.children.length - 1 - i].innerHTML;
                    this.img.children[this.img.children.length - 1 - i].innerHTML = this.img.children[i].innerHTML;
                    this.img.children[this.img.children.length - 1 - i].className = "pic" + (7-i);
                    this.img.children[this.img.children.length - 1 - i].style="";
                    this.img.children[i].innerHTML = inner;
                    this.img.children[i].className = "pic" + i;
                    this.img.children[i].style = "";
                    this.img.children[i].style.opacity=0.7;
                    this.img.children[this.img.children.length - 1 - i].style.opacity=0.7;
                    this.img.children[3].style.opacity=1;
                }
                this.direction=0;
            }
            this.timer = setInterval(this.moveLeftStep.bind(this), this.interval);
            this.canMove=1;
            for(var n=0;n<this.CENTRE+1;n++){
                this.img.children[n].style.zIndex=this.ZINDEX;
                this.ZINDEX+=1;
            }
            for(var n=this.CENTRE+1;n<this.img.children.length;n++){
                this.img.children[n].style.zIndex=this.ZINDEX;
                this.ZINDEX-=1;
            }
        }
    },
    moveLeftStep:function(){
        this.moved+=1;
        this.LILEFT-=this.step;
        this.LIWIDTH-=this.step;
        this.LITOP+=this.top;
        this.OPACITY0-=this.opacity;

        this.img.children[this.CENTRE].style.opacity=this.OPACITY0;
        for(var i=0;i<this.CENTRE+1;i++) {
            this.img.children[i].children[0].style.width = this.LIWIDTH - this.WINTERVAL*(this.CENTRE-i) + "px";
            this.img.children[i].style.top = this.LITOP + this.TINTERVAL*(this.CENTRE-i) + "px";
            this.img.children[i].style.left= this.LILEFT - this.WINTERVAL*(this.CENTRE-i) + "px";
        }

        this.LILEFT-=this.step*this.moved;
        this.LIWIDTH+=this.step*this.moved*2;
        this.LITOP-=this.top*this.moved*2;
        this.OPACITY1+=this.opacity;

        this.img.children[this.CENTRE+1].style.opacity=this.OPACITY1;
        for(var j=this.CENTRE+1;j<this.img.children.length;j++) {
            this.img.children[j].children[0].style.width = this.LIWIDTH - this.WINTERVAL*(j-3) + "px";
            this.img.children[j].style.top = this.LITOP + this.TINTERVAL*(j-3) + "px";
            this.img.children[j].style.left= this.LILEFT + this.WINTERVAL*(j-3)*2 + "px";
        }
        this.LILEFT+=this.step*this.moved;
        this.LIWIDTH-=this.step*this.moved*2;
        this.LITOP+=this.top*this.moved*2;
        //console.log(this.img.children[3].children[0]);
        if(this.moved==this.STEP){
            this.LILEFT+=this.step*this.moved;
            this.LIWIDTH+=this.step*this.moved;
            this.LITOP-=this.top*this.moved;
            this.OPACITY0+=this.opacity*this.moved;
            this.OPACITY1-=this.opacity*this.moved;

            clearInterval(this.timer);
            this.timer=null;
            this.moved=0;
            this.canMove=0;

            this.img.children[0].className+=" none";
            this.img.children[0].style.left=parseFloat(getComputedStyle(this.img.children[this.img.children.length-1]).left)+this.WINTERVAL*2+"px";
            this.img.appendChild(this.img.children[0]);
        }
    },
    moveRight:function(){
        if(!this.canMove) {
            this.img.children[0].className="";
            if(!this.direction) {
                for (var i = 0; i < this.img.children.length / 2; i++) {
                    var inner = this.img.children[this.img.children.length - 1 - i].innerHTML;
                    this.img.children[this.img.children.length - 1 - i].innerHTML = this.img.children[i].innerHTML;
                    this.img.children[this.img.children.length - 1 - i].className = "pic" + i;
                    this.img.children[this.img.children.length - 1 - i].style="";
                    this.img.children[i].innerHTML = inner;
                    this.img.children[i].className = "pic" + (7 - i);
                    this.img.children[i].style = "";
                    if(i==0){
                        this.img.children[i].className = "pic" + (i - 1);
                    }
                    this.img.children[i].style.opacity=0.7;
                    this.img.children[this.img.children.length - 1 - i].style.opacity=0.7;
                    this.img.children[4].style.opacity=1;
                }
                this.direction=1;
            }
            this.timer = setInterval(this.moveRightStep.bind(this), this.interval);
            this.canMove = 1;
            for (var n = 1; n < this.CENTRE + 2; n++) {
                this.img.children[n].style.zIndex = this.ZINDEX;
                this.ZINDEX += 1;
            }
            for (var n = this.CENTRE + 2; n < this.img.children.length; n++) {
                this.img.children[n].style.zIndex = this.ZINDEX;
                this.ZINDEX -= 1;
            }
            this.img.children[0].style.zIndex = 1;

        }
    },
    moveRightStep:function(){
        this.moved+=1;
        this.LILEFT+=this.step*2;
        this.LIWIDTH-=this.step;
        this.LITOP+=this.top;
        this.OPACITY0-=this.opacity;

        this.img.children[this.CENTRE+1].style.opacity=this.OPACITY0;
        for(var i=1;i<this.CENTRE+2;i++) {
            this.img.children[i].children[0].style.width = this.LIWIDTH - this.WINTERVAL*(this.CENTRE+1-i) + "px";
            this.img.children[i].style.top = this.LITOP + this.TINTERVAL*(this.CENTRE+1-i) + "px";
            this.img.children[i].style.left= this.LILEFT + this.WINTERVAL*(this.CENTRE+1-i)*2 + "px";
        }

        this.LILEFT-=this.step*this.moved;
        this.LIWIDTH+=this.step*this.moved*2;
        this.LITOP-=this.top*this.moved*2;
        this.OPACITY1+=this.opacity;

        this.img.children[this.CENTRE+2].style.opacity=this.OPACITY1;
        for(var j=this.CENTRE+2;j<this.img.children.length;j++) {
            this.img.children[j].children[0].style.width = this.LIWIDTH - this.WINTERVAL*(j-4) + "px";
            this.img.children[j].style.top = this.LITOP + this.TINTERVAL*(j-4) + "px";
            this.img.children[j].style.left= this.LILEFT - this.WINTERVAL*(j-4) + "px";
        }
        this.img.children[0].children[0].style.width = this.LIWIDTH - this.WINTERVAL*4 + "px";
        this.img.children[0].style.top = this.LITOP + this.TINTERVAL*4 + "px";
        this.img.children[0].style.left= this.LILEFT - this.WINTERVAL*4 + "px";

        this.LILEFT+=this.step*this.moved;
        this.LIWIDTH-=this.step*this.moved*2;
        this.LITOP+=this.top*this.moved*2;
        //console.log(this.img.children[3].children[0]);
        if(this.moved==this.STEP){
            this.LILEFT-=this.step*this.moved*2;
            this.LIWIDTH+=this.step*this.moved;
            this.LITOP-=this.top*this.moved;
            this.OPACITY0+=this.opacity*this.moved;
            this.OPACITY1-=this.opacity*this.moved;

            clearInterval(this.timer);
            this.timer=null;
            this.moved=0;
            this.canMove=0;

            this.img.children[1].className+=" none";
            this.img.children[1].style.left=parseFloat(getComputedStyle(this.img.children[0]).left)-this.WINTERVAL+"px";
            this.img.appendChild(this.img.children[0]);
        }
    }
};
Carousel.init();